<?php

return [
    'supported' => [
        'Platform\Page\Models\Page',
        'Platform\Blog\Models\Post',
        'Platform\Blog\Models\Category',
    ],
];
