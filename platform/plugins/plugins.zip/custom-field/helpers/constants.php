<?php

if (!defined('CUSTOM_FIELD_MODULE_SCREEN_NAME')) {
    define('CUSTOM_FIELD_MODULE_SCREEN_NAME', 'custom-field');
}

if (!defined('CUSTOM_FIELD_CACHE_GROUP')) {
    define('CUSTOM_FIELD_CACHE_GROUP', 'custom-field-cache-group');
}
