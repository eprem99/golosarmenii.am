<textarea name="custom_fields" id="custom_fields_json"
          class="hidden form-control"
          style="display: none !important;"
          cols="30" rows="10">{!! isset($customFieldBoxes) ? base64_encode($customFieldBoxes) : '' !!}</textarea>
<div id="custom_fields_container"></div>
