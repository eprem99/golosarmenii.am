<i class="fas fa-cloud-upload-alt"></i> {{ trans('plugins/custom-field::base.import') }}
