<?php

namespace Platform\CustomField\Repositories\Interfaces;

use Platform\Support\Repositories\Interfaces\RepositoryInterface;

interface CustomFieldInterface extends RepositoryInterface
{
}
