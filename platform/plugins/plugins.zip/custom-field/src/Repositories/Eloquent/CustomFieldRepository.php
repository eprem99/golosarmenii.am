<?php

namespace Platform\CustomField\Repositories\Eloquent;

use Platform\CustomField\Repositories\Interfaces\CustomFieldInterface;
use Platform\Support\Repositories\Eloquent\RepositoriesAbstract;

class CustomFieldRepository extends RepositoriesAbstract implements CustomFieldInterface
{
}
