<?php

use Botble\Blog\Models\Post;

return [
    'supported' => [
        Post::class,
    ],
];
