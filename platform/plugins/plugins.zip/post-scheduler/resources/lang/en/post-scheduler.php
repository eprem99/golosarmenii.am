<?php

return [
    'name'                                => 'Post Scheduler',
    'publish_date'                        => 'Publish date',
    'date'                                => 'Date',
    'time'                                => 'Time',
    'update_publish_time_to_current_time' => 'Update published time to current time',
];
