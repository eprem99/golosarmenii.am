<div class="form-group">
    <p>{{ trans('plugins/subscribe::subscribe.shortcode_content_description') }}</p>
</div>
