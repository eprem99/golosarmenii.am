{!! Form::open(['route' => 'public.send.subscribe', 'method' => 'POST', 'class' => 'subscribe-form']) !!}
    <div class="subscribe-form-row">
        <div class="subscribe-column-6">
            <div class="subscribe-form-group">
               <input type="text" class="subscribe-form-input" name="name" value="{{ old('name') }}" id="subscribe_name"
                       placeholder="{{ __('Name') }}">
            </div>
        </div>
        <div class="subscribe-column-6">
            <div class="subscribe-form-group">
                <label for="subscribe_email" class="subscribe-label required">{{ __('Email') }}</label>
                <input type="email" class="subscribe-form-input" name="email" value="{{ old('email') }}" id="subscribe_email"
                       placeholder="{{ __('Email') }}">
            </div>
        </div>
    </div>

    @if (setting('enable_captcha') && is_plugin_active('captcha'))
        <div class="subscribe-form-row">
            <div class="subscribe-column-12">
                <div class="subscribe-form-group">
                    {!! Captcha::display() !!}
                </div>
            </div>
        </div>
    @endif

    <div class="subscribe-form-group"><p>{!! clean(__('The field with (<span style="color:#FF0000;">*</span>) is required.')) !!}</p></div>

    <div class="subscribe-form-group">
        <button type="submit" class="subscribe-button">{{ __('Send') }}</button>
    </div>

    <div class="subscribe-form-group">
        <div class="subscribe-message subscribe-success-message" style="display: none"></div>
        <div class="subscribe-message subscribe-error-message" style="display: none"></div>
    </div>

{!! Form::close() !!}
