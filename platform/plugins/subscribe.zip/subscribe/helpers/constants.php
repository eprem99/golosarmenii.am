<?php

if (!defined('SUBSCIBES_MODULE_SCREEN_NAME')) {
    define('SUBSCIBES_MODULE_SCREEN_NAME', 'subscribe');
}

if (!defined('SUBSCIBES_UNREAD_COUNT')) {
    define('SUBSCIBES_UNREAD_COUNT', 'subscribe_unread_count');
}

if (!defined('SUBSCIBES_FORM_TEMPLATE_VIEW')) {
    define('SUBSCIBES_FORM_TEMPLATE_VIEW', 'subscribe-form-template-view');
}
