<?php

if (!defined('COMMENTS_MODULE_SCREEN_NAME')) {
    define('COMMENTS_MODULE_SCREEN_NAME', 'comments');
}

if (!defined('COMMENTS_UNREAD_COUNT')) {
    define('COMMENTS_UNREAD_COUNT', 'comments_unread_count');
}

if (!defined('COMMENTS_FORM_TEMPLATE_VIEW')) {
    define('COMMENTS_FORM_TEMPLATE_VIEW', 'comments-form-template-view');
}
