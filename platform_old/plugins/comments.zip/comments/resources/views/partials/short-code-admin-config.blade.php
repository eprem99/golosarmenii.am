<div class="form-group">
    <p>{{ trans('plugins/comments::comments.shortcode_content_description') }}</p>
</div>
