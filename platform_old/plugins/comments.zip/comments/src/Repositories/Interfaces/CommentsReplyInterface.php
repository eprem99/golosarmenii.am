<?php

namespace Botble\Comments\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface CommentsReplyInterface extends RepositoryInterface
{
}
